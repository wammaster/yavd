#include "stdafx.h"
#include "trees.h"

//HTREEITEM Tree_Insert(CTreeCtrl* CTree,char* cBuffer,HTREEITEM hParent,HTREEITEM hAfter)


