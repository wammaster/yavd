/*

  secure division

*/

#ifndef I_DEBUG
#define I_DEBUG

#include "windows.h"


__int64 QW_div(__int64 x, __int64 y, char* lpName);
double d_div(double x, double y, char* lpName);


#endif