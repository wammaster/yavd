#ifndef I_TYPES
#define I_TYPES

#define QUADWORD _int64


#endif