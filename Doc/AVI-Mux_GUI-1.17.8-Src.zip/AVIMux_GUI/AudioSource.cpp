/*

to do
-----

  add support for duration stuff when a file in a list ends

  */

#include "stdafx.h"
#include "..\basestreams.h"
#include "audiosource.h"
#include "silence.h"
#include "debug.h"



static const char* audioformat_names[] =
{ "MP3-CBR", "MP3-VBR", "AC3", "DTS" };




