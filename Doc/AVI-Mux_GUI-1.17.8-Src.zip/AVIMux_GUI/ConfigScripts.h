#ifndef I_CONFIGSCRIPTS
#define I_CONFIGSCRIPTS

bool	LoadScript(char* lpcName,HWND hwnd,UINT message);

#endif