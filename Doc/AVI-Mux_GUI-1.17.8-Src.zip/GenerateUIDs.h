#ifndef I_GENERATE_UIDS
#define I_GENERATE_UIDS

void generate_uid(char* pDest, int len);

#endif