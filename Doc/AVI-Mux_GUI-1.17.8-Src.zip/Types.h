#ifndef I_TYPES
#define I_TYPES

#define QUADWORD __int64

#define uint8 unsigned __int8
#define uint16 unsigned __int16
#define uint32 unsigned __int32
#define uint64 unsigned __int64

#ifndef uint
#define uint uint32
#endif

#endif