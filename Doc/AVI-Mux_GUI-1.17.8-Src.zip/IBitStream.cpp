#include "stdafx.h"
#include "IBitStream.h"

IBitStream::IBitStream()
{
}

IBitStream::~IBitStream()
{
}