#ifndef I_FORMATI64
#define I_FORMATI64

void	QW2Str(__int64 qwX,char*	lpDest,int  dwLen);

#endif